'use client';

const WhatsNew = () => (
  <section>
    What's new section
  </section>
);

export default WhatsNew;
