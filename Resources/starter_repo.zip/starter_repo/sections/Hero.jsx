'use client';

const Hero = () => (
  <section>
    Hero section
  </section>
);

export default Hero;
