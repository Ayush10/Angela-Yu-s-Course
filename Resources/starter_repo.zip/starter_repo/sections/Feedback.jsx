'use client';

const Feedback = () => (
  <section>
    Feedback section
  </section>
);

export default Feedback;
