'use client';

const Insights = () => (
  <section>
    Insights section
  </section>
);

export default Insights;
