const StartSteps = () => (
  <div>
    start steps
  </div>
);

export default StartSteps;
