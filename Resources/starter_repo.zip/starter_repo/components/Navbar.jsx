'use client';

const Navbar = () => (
  <nav>
    navbar
  </nav>
);

export default Navbar;
